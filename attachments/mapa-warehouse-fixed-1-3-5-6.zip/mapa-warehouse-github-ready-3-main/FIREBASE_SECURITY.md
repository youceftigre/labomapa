# تأمين Firebase — MAPA Smart Warehouse

## 1) نشر القواعد (مهم)

الملفات جاهزة في المشروع:
- `firestore.rules`
- `storage.rules`

### من واجهة Firebase
1. افتح [Firebase Console](https://console.firebase.google.com) → مشروع `magasine-6f1ef`
2. **Firestore Database** → **Rules** → الصق محتوى `firestore.rules` → **Publish**
3. **Storage** → **Rules** → الصق محتوى `storage.rules` → **Publish**

### من سطر الأوامر (إن وُجد Firebase CLI)
```bash
firebase deploy --only firestore:rules,storage
```

## 2) ماذا تفعل هذه القواعد؟
- ترفض كتابات المواد/العمليات ذات الشكل غير الصالح
- تمنع الكتابة خارج المجموعات المعروفة
- تحدّ حجم صور Storage إلى أقل من 3 MB

## 3) حدود الأمان الحالية
التطبيق يستخدم كلمة مرور محلية في المتصفح (وليس Firebase Auth)، لذلك:
- من يستطيع فتح التطبيق وفهم الكود ما زال قادراً على الكتابة بالشكل الصحيح
- للحماية الأقوى لاحقاً: فعّل **Firebase Authentication** واربط القواعد بـ `request.auth != null`

## 4) توصية إضافية
- اجعل مستودع GitHub **Private**
- لا تشارك رابط لوحة Firebase علناً
- غيّر كلمات مرور الأدوار بشكل دوري
